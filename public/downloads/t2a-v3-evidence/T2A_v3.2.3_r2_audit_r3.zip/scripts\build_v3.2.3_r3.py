#!/usr/bin/env python3
"""Safely rebuild an isolated v3.2.3 r2 audit-r3 working directory."""
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

MARKER = ".t2a_audit_build_output"


def contained(path, parent):
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def validate_output(output, package, source):
    output = output.resolve()
    forbidden = {package.resolve(), source.resolve(), Path.cwd().resolve(), Path(output.anchor).resolve()}
    if output in forbidden or contained(output, source.resolve()):
        raise SystemExit(f"unsafe output directory: {output}")
    return output


def guarded_remove(output, package, source, overwrite):
    if not output.exists():
        return
    if not overwrite:
        raise SystemExit(f"output exists; pass --overwrite only for a marked build directory: {output}")
    validate_output(output, package, source)
    if not (output / MARKER).is_file():
        raise SystemExit(f"refusing to remove unmarked directory: {output}")
    print(f"REMOVING MARKED OUTPUT: {output.resolve()}")
    shutil.rmtree(output)


def main():
    default_package = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, default=default_package)
    parser.add_argument("--source-dir", type=Path)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--phase1-source", type=Path)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    package = args.package_root.resolve()
    source = (args.source_dir or package / "source").resolve()
    output = validate_output(args.output_dir or package / "rebuilt", package, source)
    if not package.is_dir() or not source.is_dir():
        raise SystemExit("package-root and source-dir must exist")
    phase1 = args.phase1_source.resolve() if args.phase1_source else None
    if phase1 is not None and not phase1.exists():
        raise SystemExit(f"phase1 source does not exist: {phase1}")

    print(f"PACKAGE_ROOT={package}")
    print(f"SOURCE_DIR={source}")
    print(f"OUTPUT_DIR={output}")
    print(f"PHASE1_SOURCE={phase1 or 'not supplied; packaged harmonized Phase 1 rows retained'}")
    print(f"OVERWRITE={args.overwrite}")
    if args.dry_run:
        print("DRY RUN: no files written or removed")
        return

    guarded_remove(output, package, source, args.overwrite)
    output.mkdir(parents=True)
    (output / MARKER).write_text("created by build_v3.2.3_r3.py\n", encoding="utf-8")
    for name in ("source", "derived", "reports", "scripts", "manifests"):
        shutil.copytree(package / name, output / name)
    for name in ("README_AUDIT.md", "AUDIT_REVISION_NOTES.md"):
        shutil.copy2(package / name, output / name)
    subprocess.run([sys.executable, str(output / "scripts/recompute_repeat_consistency_v3.2.3.py")], cwd=output, check=True)
    subprocess.run([sys.executable, str(output / "scripts/bootstrap_prompt_cluster_v3.2.3.py")], cwd=output, check=True)
    print("REBUILT WORKING DIRECTORY CREATED; regenerate manifest after any artifact change")


if __name__ == "__main__":
    main()
