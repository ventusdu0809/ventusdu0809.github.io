#!/usr/bin/env python3
"""Comprehensive validator for T2A v3.2.3 r2 audit revision r3."""
import csv
import hashlib
import json
import re
import subprocess
import sys
import tempfile
from collections import defaultdict
from pathlib import Path
from statistics import mean

from scipy.stats import rankdata, spearmanr, wilcoxon

ROOT = Path(__file__).resolve().parent.parent
DIAG = [
    "wrong_source", "missing_secondary_event", "extra_event", "wrong_count",
    "wrong_attribute", "wrong_temporal_order", "artifact_noise", "abrupt_cutoff",
    "clipping", "silence", "texture_ambiguity", "other",
]
FROZEN_HASHES = {
    "source/core_prompts_40.csv": "0d458c580fdd4b08dcf9a3f70ede4942314051242c352bec430c73527880e061",
    "source/formal_scores_audited_v2.0.3.csv": "bf8676eb2a03ee88ef5e55f4dcf708da72a50c27ee034787bedbb4fe792f6182",
    "source/formal_scores_unblinded_n400_v2.0.3.csv": "a2aa935313fa72947d0087c4e0c8996ed1bf615ba9b3851342d52b1c7aad9520",
    "source/ratings_harmonized_600.csv": "97e826d8e3e495eb6c14552770a63a2143e6218902747d0191f9f14f12205862",
    "derived/badcase_conditional_rate_v3.2.3.csv": "7938412ad7936fa3a18fe48ee63b979de8b11395015a022150fbc431b38e4577",
    "derived/badcase_persistence_960.csv": "120f689f005349c02395afd7018eb3af29fecdc12f4cbf550b9f8b3017ba511d",
    "derived/multilabel_badcase_summary_v3.2.csv": "0a9f017e75b991efd211877c965593d3c43af6ff2ffee2afabbd9430bc812254",
    "derived/prompt_event_requirements_v3.2.3.csv": "6bc0ce1f5e645f2a589cf68ecf930a422ee8b1bef0f0d7c01a32384c908eb8e3",
    "derived/sao1_historical_bridge_v3.2.csv": "99526c53cec2630b7417157de6f19241ab334245669e2e06c5bbab1344ce546d",
    "derived/wilcoxon_robustness_v3.2.csv": "aeb1d909e0b6f4e66e7570f2850a3142299ed790b84504c4d169828c65ec6483",
}
failures = []


def check(condition, message):
    if not condition:
        failures.append(message)
        print(f"FAIL: {message}")


def load(relative):
    with (ROOT / relative).open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def close(a, b, tolerance=1e-9):
    return abs(float(a) - float(b)) <= tolerance


def validate_manifest():
    manifest_path = ROOT / "manifests/audit_manifest_sha256_v3.2.3_r3.txt"
    lines = manifest_path.read_text(encoding="utf-8").splitlines()
    tracked = {}
    for line in lines:
        match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        check(match is not None, f"invalid manifest line: {line}")
        if match:
            tracked[match.group(2)] = match.group(1)
    actual = {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob("*")
        if path.is_file() and path != manifest_path
    }
    check("README_AUDIT.md" in tracked, "README is not manifest-managed")
    check(set(tracked) == actual, f"manifest coverage mismatch missing={sorted(actual-set(tracked))} extra={sorted(set(tracked)-actual)}")
    for relative, expected in tracked.items():
        path = ROOT / relative
        check(path.is_file() and digest(path) == expected, f"manifest hash mismatch: {relative}")


def validate_security():
    forbidden_names = {"blind_map_private_v2.csv", "hidden_repeat_pairs_n40.csv"}
    check(not any(path.name in forbidden_names for path in ROOT.rglob("*")), "private blind-map artifact included")
    pair_header = set(load("source/hidden_repeat_pairs_audit_safe_v3.2.3.csv")[0])
    check(not pair_header.intersection({"model", "prompt_id", "seed", "source_file", "path"}), "pair table contains private identity fields")
    secret_patterns = [
        re.compile(r"AKIA[0-9A-Z]{16}"),
        re.compile(r"hf_[A-Za-z0-9]{20,}"),
        re.compile(r"sk-[A-Za-z0-9_-]{20,}"),
        re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
        re.compile(r"(?:api[_-]?key|password|secret)\s*[:=]\s*['\"][^'\"]+", re.I),
        re.compile(r"C:\\Users\\", re.I),
        re.compile(r"/(?:Users|home)/", re.I),
    ]
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".py", ".md", ".json", ".txt", ".csv"}:
            continue
        text = path.read_text(encoding="utf-8-sig", errors="replace")
        for pattern in secret_patterns:
            check(pattern.search(text) is None, f"security pattern {pattern.pattern} in {path.relative_to(ROOT)}")
    build = (ROOT / "scripts/build_v3.2.3_r3.py").read_text(encoding="utf-8")
    check("D:/" not in build and "D:\\" not in build, "build contains fixed D-drive path")
    for token in ("--overwrite", "--dry-run", ".t2a_audit_build_output", "unsafe output directory"):
        check(token in build, f"build safety token missing: {token}")
    check(build.count("shutil.rmtree(") == 1 and "guarded_remove(" in build, "build removal is not uniquely guarded")


def main():
    canonical = load("source/formal_scores_audited_v2.0.3.csv")
    n400 = load("source/formal_scores_unblinded_n400_v2.0.3.csv")
    harmonized = load("source/ratings_harmonized_600.csv")
    prompts = load("source/core_prompts_40.csv")
    events = load("derived/prompt_event_requirements_v3.2.3.csv")
    persistence = load("derived/badcase_persistence_960.csv")
    check(len(canonical) == 440 and len({r["blind_id"] for r in canonical}) == 440, "canonical row/key count")
    check(len(n400) == 400 and len({r["blind_id"] for r in n400}) == 400, "n400 row/key count")
    check(len(harmonized) == 600, "harmonized row count")
    check(len(prompts) == 40 and len({r["prompt_id"] for r in prompts}) == 40, "prompt count")
    check(len(events) == 41 and len({r["prompt_id"] for r in events}) == 40, "requirement row/prompt count")
    check(len(persistence) == 960 and len({(r["model"],r["prompt_id"],r["tag"]) for r in persistence}) == 960, "persistence row/key count")
    for rows, ovl, rel, name in ((canonical,"OVL_1_to_5","REL_1_to_5","canonical"),(n400,"OVL_1_to_5","REL_1_to_5","n400"),(harmonized,"OVL","REL","harmonized")):
        check(all(r[ovl] in {"1","2","3","4","5"} and r[rel] in {"1","2","3","4","5"} for r in rows), f"{name} score range")
    check(all(r[d] in {"0","1"} for r in canonical for d in DIAG), "canonical diagnostic values")
    check(all((r["primary_badcase"] in {"", "none"} and not any(r[d]=="1" for d in DIAG)) or (r["primary_badcase"] not in {"", "none"} and r.get(r["primary_badcase"])=="1") for r in canonical), "primary/multilabel structure")

    for relative, expected in FROZEN_HASHES.items():
        check(digest(ROOT / relative) == expected, f"frozen file changed: {relative}")

    pairs = load("source/hidden_repeat_pairs_audit_safe_v3.2.3.csv")
    cm = {r["blind_id"]: r for r in canonical}
    formal_ids = {r["blind_id"] for r in n400}
    check(len(pairs) == 40 and len({r["pair_id"] for r in pairs}) == 40, "repeat pair count/key")
    original_ids = [r["original_blind_id"] for r in pairs]
    repeat_ids = [r["repeat_blind_id"] for r in pairs]
    check(len(set(original_ids + repeat_ids)) == 80, "repeat Blind IDs reused")
    check(all(x in formal_ids for x in original_ids), "original repeat-pair ID not formal")
    check(all(x in cm and x not in formal_ids for x in repeat_ids), "repeat ID not in canonical-minus-formal")
    check(all(r["audio_hash_match"]=="1" and r["original_audio_sha256"]==r["repeat_audio_sha256"] and len(r["original_audio_sha256"])==64 for r in pairs), "repeat audio SHA256 verification")
    check(sum(r["same_session"]=="1" for r in pairs) == 4, "actual same-session count")
    check(sum(int(r["presentation_gap"])>=30 for r in pairs) == 34, "actual gap>=30 count")
    check(all(int(r["presentation_gap"])==abs(int(cm[r["original_blind_id"]]["presentation_order"])-int(cm[r["repeat_blind_id"]]["presentation_order"])) for r in pairs), "pair gap not canonical-derived")

    repeat_result = {r["subset"]:r for r in load("derived/repeat_consistency_v3.2.3.csv")}
    expected_repeat = {
        "all_pairs": (40,22,38,25,39,34,27),
        "gap_ge_30": (34,17,32,20,33,29,23),
    }
    for subset, values in expected_repeat.items():
        row = repeat_result.get(subset, {})
        fields = ("pair_n","OVL_exact_n","OVL_within_one_n","REL_exact_n","REL_within_one_n","decision_exact_n","primary_exact_n")
        check(tuple(int(row.get(field,-1)) for field in fields) == values, f"repeat metrics {subset}")

    models = {m:[r for r in n400 if r["bm_source_model"]==m] for m in ("SA3M","SAO1")}
    check({m:len(v) for m,v in models.items()} == {"SA3M":200,"SAO1":200}, "model counts")
    means = {m:(mean(int(r["OVL_1_to_5"]) for r in rows),mean(int(r["REL_1_to_5"]) for r in rows)) for m,rows in models.items()}
    check(means == {"SA3M":(3.64,3.305),"SAO1":(3.78,3.355)}, "model means")
    check(sum(r["texture_ambiguity"]=="1" for r in models["SA3M"])==11 and sum(r["texture_ambiguity"]=="1" for r in models["SAO1"])==16, "texture counts")

    global_rows = {r["tag"]:r for r in load("derived/multilabel_badcase_summary_v3.2.csv")}
    for tag in DIAG:
        for model in models:
            count = sum(r[tag]=="1" for r in models[model])
            check(int(global_rows[tag][f"{model}_count"]) == count, f"global Badcase {model}/{tag}")

    prompt_has = defaultdict(lambda: defaultdict(bool))
    for event in events:
        pid = event["prompt_id"]
        prompt_has[pid]["has_source"] = True
        prompt_has[pid]["has_explicit_count"] |= event["count_type"] == "explicit_exact"
        prompt_has[pid]["has_implicit_single"] |= event["count_type"] == "implicit_single"
        has_secondary = event["has_secondary"].strip()=="1" or event["role"]=="secondary"
        prompt_has[pid]["has_secondary_event"] |= has_secondary
        prompt_has[pid]["has_temporal"] |= has_secondary or bool(event["temporal_relation"].strip())
        prompt_has[pid]["has_sonic_component"] |= bool(event["sonic_components"].strip())
        prompt_has[pid]["has_attribute"] |= bool(event["attributes"].strip())
    condition_map = {
        "wrong_source":("has_source","wrong_source"),
        "wrong_count_explicit":("has_explicit_count","wrong_count"),
        "wrong_count_implicit":("has_implicit_single","wrong_count"),
        "missing_secondary_event":("has_secondary_event","missing_secondary_event"),
        "missing_sonic_component":("has_sonic_component","missing_secondary_event"),
        "wrong_attribute":("has_attribute","wrong_attribute"),
        "wrong_temporal_order":("has_temporal","wrong_temporal_order"),
    }
    conditional = {r["label"]:r for r in load("derived/badcase_conditional_rate_v3.2.3.csv")}
    for name,(field,label) in condition_map.items():
        for model,rows in models.items():
            subset = [r for r in rows if prompt_has[r["bm_prompt_id"]][field]]
            check(int(conditional[name][f"{model}_n"])==sum(r[label]=="1" for r in subset) and int(conditional[name][f"{model}_denom"])==len(subset), f"conditional {name}/{model}")

    expected_persistence = set()
    for model,rows in models.items():
        by_prompt = defaultdict(list)
        for row in rows: by_prompt[row["bm_prompt_id"]].append(row)
        for prompt in sorted({r["prompt_id"] for r in prompts}):
            for tag in DIAG:
                count = sum(r[tag]=="1" for r in by_prompt[prompt])
                cls = "not_observed" if count==0 else "sporadic" if count==1 else "unstable" if count<=3 else "persistent"
                expected_persistence.add((model,prompt,tag,count,cls))
    observed_persistence = {(r["model"],r["prompt_id"],r["tag"],int(r["count"]),r["persistence_class"]) for r in persistence}
    check(expected_persistence == observed_persistence, "persistence contents")

    prompt_deltas = {"OVL":[],"REL":[]}
    for prompt in sorted({r["bm_prompt_id"] for r in n400}):
        for metric,column in (("OVL","OVL_1_to_5"),("REL","REL_1_to_5")):
            prompt_deltas[metric].append(mean(int(r[column]) for r in models["SA3M"] if r["bm_prompt_id"]==prompt)-mean(int(r[column]) for r in models["SAO1"] if r["bm_prompt_id"]==prompt))
    wilcoxon_rows = {r["metric"]:r["value"] for r in load("derived/wilcoxon_robustness_v3.2.csv")}
    for metric in ("OVL","REL"):
        values = prompt_deltas[metric]
        result = wilcoxon(values,zero_method="wilcox",alternative="two-sided",method="approx",correction=False)
        nonzero = [v for v in values if abs(v)>1e-12]
        ranks = rankdata([abs(v) for v in nonzero],method="average")
        rbc = (sum(rank for rank,v in zip(ranks,nonzero) if v>0)-sum(rank for rank,v in zip(ranks,nonzero) if v<0))/sum(ranks)
        check(close(wilcoxon_rows[f"{metric}_T"],result.statistic) and close(wilcoxon_rows[f"{metric}_p"],result.pvalue,1e-6) and close(wilcoxon_rows[f"{metric}_rbc"],rbc,1e-6), f"Wilcoxon/RBC {metric}")

    phase1 = [r for r in harmonized if r["phase_id"]=="phase_1" and r["model_id"]=="SAO1"]
    phase2 = [r for r in harmonized if r["phase_id"]=="phase_2" and r["model_id"]=="SAO1"]
    bridge_rows = {r["metric"]:r["value"] for r in load("derived/sao1_historical_bridge_v3.2.csv")}
    for metric in ("OVL","REL"):
        a=defaultdict(list); b=defaultdict(list)
        for r in phase1:a[r["prompt_id"]].append(int(r[metric]))
        for r in phase2:b[r["prompt_id"]].append(int(r[metric]))
        common=sorted(set(a)&set(b)); av=[mean(a[p]) for p in common]; bv=[mean(b[p]) for p in common]
        rho=float(spearmanr(av,bv).statistic); mad=mean(abs(x-y) for x,y in zip(av,bv))
        check(len(common)==40 and close(bridge_rows[f"{metric}_Spearman_rho"],rho,5e-5) and close(bridge_rows[f"{metric}_MAD"],mad,5e-5), f"historical bridge {metric}")

    with tempfile.TemporaryDirectory() as temp:
        temp=Path(temp)
        repeat_temp=temp/"repeat.csv"; bootstrap_temp=temp/"bootstrap.csv"
        repeat_run=subprocess.run([sys.executable,str(ROOT/"scripts/recompute_repeat_consistency_v3.2.3.py"),"--output",str(repeat_temp)],cwd=ROOT,capture_output=True,text=True)
        boot_run=subprocess.run([sys.executable,str(ROOT/"scripts/bootstrap_prompt_cluster_v3.2.3.py"),"--output",str(bootstrap_temp)],cwd=ROOT,capture_output=True,text=True)
        check(repeat_run.returncode==0 and repeat_temp.read_bytes()==(ROOT/"derived/repeat_consistency_v3.2.3.csv").read_bytes(), "repeat script execution/reproduction")
        check(boot_run.returncode==0 and bootstrap_temp.read_bytes()==(ROOT/"derived/bootstrap_model_difference_v3.2.3.csv").read_bytes(), "Bootstrap script execution/reproduction")
    bootstrap_rows = {r["metric"]:r for r in load("derived/bootstrap_model_difference_v3.2.3.csv")}
    expected_boot = {"OVL":(-0.14,-0.395,0.115),"REL":(-0.05,-0.295,0.18)}
    for metric,(delta,low,high) in expected_boot.items():
        row=bootstrap_rows[metric]
        check(close(row["observed_delta"],delta) and close(row["ci_low"],low) and close(row["ci_high"],high), f"Bootstrap values {metric}")
        check(row["prompt_n"]=="40" and row["iterations"]=="10000" and row["seed"]=="42" and row["analysis_unit"]=="prompt" and row["paired_resampling"]=="true", f"Bootstrap settings {metric}")

    report=(ROOT/"reports/T2A_Evaluation_Report_v3.2.3_r3.md").read_text(encoding="utf-8")
    for text in ("3.640","3.305","3.780","3.355","38/40","39/40","32/34","33/34","Four pairs were within the same session"):
        check(text in report, f"report disclosure missing: {text}")
    for forbidden in ("models are equivalent","significant improvement","multimodal evaluation","multiple evaluators","all repeated presentations occurred in the final"):
        check(forbidden.lower() not in report.lower(), f"unsupported report claim: {forbidden}")

    validate_security()
    validate_manifest()
    if failures:
        print(f"{len(failures)} CHECKS FAILED")
        raise SystemExit(1)
    print("ALL CHECKS PASSED")


if __name__ == "__main__":
    main()
