# T2A Evaluation Program v3.2.3 r2 — Audit Package Revision r3

## Classification: INTERNAL AUDIT

`r3` is an audit-packaging revision. The frozen research version remains
T2A Evaluation Program v3.2.3 r2. No human rating, diagnostic label, or
adjudication decision was changed.

The ZIP contains 23 files: 22 manifest-managed payload files plus the
SHA256 manifest itself. Directory counts are source=5, derived=9,
reports=1, scripts=5, manifests=1, with two root documents.

## Audit r3 changes

- Added a 40-row audit-safe hidden-repeat pair table with full audio SHA256.
- Added independently executable repeat-consistency recomputation.
- Restored the original prompt-level paired Bootstrap implementation:
  10,000 iterations, seed 42, Python `random.Random` MT19937, and the
  original sorted order-statistic endpoints.
- Replaced fixed local build paths with a parameterized, guarded builder.
- Expanded validation to cover manifest, frozen hashes, statistics,
  repeat consistency, Bootstrap, and security checks.
- Included this README in the SHA256 manifest.
- Standardized technical-report model means to three decimal places.
- Corrected the historical v3.1 session/gap estimate to use actual
  canonical presentation order and session metadata.

## Reproducibility and safe execution

From an isolated extracted copy, run:

```text
python scripts/validate_v3.2.3_r3.py
```

The validator and all Phase 2 calculations run from packaged sources.
The packaged harmonized table is sufficient to reproduce the historical
bridge. A full historical rebuild from the original Phase 1 adjudicated
archive requires that external archive to be supplied explicitly through
`--phase1-source`.

The build script defaults to a separate `rebuilt` directory. Use
`--dry-run` first. It will delete an existing output only when `--overwrite`
is explicit and the target contains `.t2a_audit_build_output`; it rejects
the package root, source directory, current directory, and disk root.
Never run overwrite against the only formal project copy.

## Method boundaries

- Single evaluator; hidden repeats measure intra-rater consistency only.
- Phase 2 is the controlled model comparison.
- Phase 1 versus Phase 2 is a non-equivalent historical bridge.
- Conditional analyses are retrospective prompt-conditioned sample-level
  label rates.
- Forty-one requirement rows represent 40 prompts and are not 41 fully
  decomposed events.
- Confidence intervals crossing zero do not establish model equivalence.

## Does not contain

- Private blind map
- Model/prompt/seed identity for hidden-repeat pairs
- API or Hugging Face tokens
- Personal user-profile paths
- Raw audio WAV files
