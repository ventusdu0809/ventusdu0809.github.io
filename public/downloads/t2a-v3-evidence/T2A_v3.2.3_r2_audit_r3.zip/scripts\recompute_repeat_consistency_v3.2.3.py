#!/usr/bin/env python3
"""Recompute audit-safe single-rater hidden-repeat consistency."""
import argparse
import csv
from pathlib import Path
from statistics import mean


def load(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def rate(numerator, denominator):
    return f"{numerator / denominator:.6f}"


def summarize(name, pairs, ratings):
    joined = []
    for pair in pairs:
        original = ratings[pair["original_blind_id"]]
        repeat = ratings[pair["repeat_blind_id"]]
        first, later = sorted(
            (original, repeat), key=lambda row: int(row["presentation_order"])
        )
        joined.append((original, repeat, first, later))

    n = len(joined)
    ovl_exact = sum(o["OVL_1_to_5"] == r["OVL_1_to_5"] for o, r, _, _ in joined)
    ovl_within = sum(
        abs(int(o["OVL_1_to_5"]) - int(r["OVL_1_to_5"])) <= 1
        for o, r, _, _ in joined
    )
    rel_exact = sum(o["REL_1_to_5"] == r["REL_1_to_5"] for o, r, _, _ in joined)
    rel_within = sum(
        abs(int(o["REL_1_to_5"]) - int(r["REL_1_to_5"])) <= 1
        for o, r, _, _ in joined
    )
    decision_exact = sum(o["decision"] == r["decision"] for o, r, _, _ in joined)
    primary_exact = sum(
        o["primary_badcase"] == r["primary_badcase"] for o, r, _, _ in joined
    )
    later_diffs = [
        int(later["OVL_1_to_5"]) - int(first["OVL_1_to_5"])
        for _, _, first, later in joined
    ]
    return {
        "subset": name,
        "pair_n": n,
        "OVL_exact_n": ovl_exact,
        "OVL_exact_rate": rate(ovl_exact, n),
        "OVL_within_one_n": ovl_within,
        "OVL_within_one_rate": rate(ovl_within, n),
        "REL_exact_n": rel_exact,
        "REL_exact_rate": rate(rel_exact, n),
        "REL_within_one_n": rel_within,
        "REL_within_one_rate": rate(rel_within, n),
        "decision_exact_n": decision_exact,
        "decision_exact_rate": rate(decision_exact, n),
        "primary_exact_n": primary_exact,
        "primary_exact_rate": rate(primary_exact, n),
        "same_session_n": sum(p["same_session"] == "1" for p in pairs),
        "later_minus_earlier_OVL_mean": f"{mean(later_diffs):.6f}",
        "later_OVL_lower_n": sum(value < 0 for value in later_diffs),
        "later_OVL_higher_n": sum(value > 0 for value in later_diffs),
        "later_OVL_same_n": sum(value == 0 for value in later_diffs),
    }


def main():
    package = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser()
    parser.add_argument("--canonical", type=Path, default=package / "source/formal_scores_audited_v2.0.3.csv")
    parser.add_argument("--pairs", type=Path, default=package / "source/hidden_repeat_pairs_audit_safe_v3.2.3.csv")
    parser.add_argument("--output", type=Path, default=package / "derived/repeat_consistency_v3.2.3.csv")
    args = parser.parse_args()

    canonical = load(args.canonical)
    pairs = load(args.pairs)
    ratings = {row["blind_id"]: row for row in canonical}
    if len(canonical) != 440 or len(ratings) != 440:
        raise SystemExit("canonical must contain 440 unique Blind IDs")
    if len(pairs) != 40 or len({row["pair_id"] for row in pairs}) != 40:
        raise SystemExit("pair table must contain 40 unique pair IDs")
    used = [row[key] for row in pairs for key in ("original_blind_id", "repeat_blind_id")]
    if len(set(used)) != 80 or any(blind_id not in ratings for blind_id in used):
        raise SystemExit("pair Blind IDs must be 80 unique canonical IDs")
    for row in pairs:
        if row["original_audio_sha256"] != row["repeat_audio_sha256"] or row["audio_hash_match"] != "1":
            raise SystemExit(f"audio hash mismatch in {row['pair_id']}")
        if len(row["original_audio_sha256"]) != 64:
            raise SystemExit(f"non-full SHA256 in {row['pair_id']}")
        original = ratings[row["original_blind_id"]]
        repeat = ratings[row["repeat_blind_id"]]
        expected_gap = abs(int(original["presentation_order"]) - int(repeat["presentation_order"]))
        if int(row["presentation_gap"]) != expected_gap:
            raise SystemExit(f"presentation gap mismatch in {row['pair_id']}")
        expected_same = "1" if original["session_id"] == repeat["session_id"] else "0"
        if row["same_session"] != expected_same:
            raise SystemExit(f"session mismatch in {row['pair_id']}")

    rows = [
        summarize("all_pairs", pairs, ratings),
        summarize("gap_ge_30", [row for row in pairs if int(row["presentation_gap"]) >= 30], ratings),
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"WROTE {args.output}")
    for row in rows:
        print(
            f"{row['subset']}: n={row['pair_n']} OVL_within_one={row['OVL_within_one_n']} "
            f"REL_within_one={row['REL_within_one_n']}"
        )


if __name__ == "__main__":
    main()
