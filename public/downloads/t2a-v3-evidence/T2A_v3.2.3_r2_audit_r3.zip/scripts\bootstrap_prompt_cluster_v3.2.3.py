#!/usr/bin/env python3
"""Reproduce the frozen prompt-level paired cluster Bootstrap."""
import argparse
import csv
import platform
import random
from collections import defaultdict
from pathlib import Path
from statistics import mean


def load(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def main():
    package = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=package / "source/formal_scores_unblinded_n400_v2.0.3.csv")
    parser.add_argument("--output", type=Path, default=package / "derived/bootstrap_model_difference_v3.2.3.csv")
    parser.add_argument("--iterations", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if args.iterations != 10000 or args.seed != 42:
        raise SystemExit("frozen audit settings require iterations=10000 and seed=42")

    rows = load(args.input)
    prompt_data = defaultdict(lambda: defaultdict(list))
    prompt_order = []
    seen = set()
    for row in rows:
        prompt = row["bm_prompt_id"]
        if prompt not in seen:
            seen.add(prompt)
            prompt_order.append(prompt)
        model = row["bm_source_model"]
        prompt_data[prompt][f"{model}_OVL"].append(int(row["OVL_1_to_5"]))
        prompt_data[prompt][f"{model}_REL"].append(int(row["REL_1_to_5"]))
    if len(rows) != 400 or len(prompt_order) != 40:
        raise SystemExit("expected 400 rows and 40 prompts")
    if any(len(prompt_data[p][f"{m}_{metric}"]) != 5 for p in prompt_order for m in ("SA3M", "SAO1") for metric in ("OVL", "REL")):
        raise SystemExit("each model x prompt cell must contain five ratings")

    deltas = {
        metric: [
            mean(prompt_data[p][f"SA3M_{metric}"]) - mean(prompt_data[p][f"SAO1_{metric}"])
            for p in prompt_order
        ]
        for metric in ("OVL", "REL")
    }
    rng = random.Random(args.seed)
    bootstrap = {"OVL": [], "REL": []}
    for _ in range(args.iterations):
        sampled = rng.choices(range(len(prompt_order)), k=len(prompt_order))
        for metric in bootstrap:
            bootstrap[metric].append(mean(deltas[metric][index] for index in sampled))

    output_rows = []
    for metric in ("OVL", "REL"):
        values = sorted(bootstrap[metric])
        output_rows.append({
            "metric": metric,
            "observed_delta": f"{mean(deltas[metric]):.6f}",
            "bootstrap_mean_delta": f"{mean(values):.6f}",
            "prompt_n": 40,
            "iterations": args.iterations,
            "seed": args.seed,
            "rng_implementation": f"python_random.Random_MT19937;python={platform.python_version()}",
            "numpy_version": "not_used",
            "quantile_method": "sorted_order_statistic_indices_250_9749_zero_based",
            "ci_level": "0.95",
            "ci_low": f"{values[250]:.6f}",
            "ci_high": f"{values[9749]:.6f}",
            "analysis_unit": "prompt",
            "paired_resampling": "true",
        })
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(output_rows[0]))
        writer.writeheader()
        writer.writerows(output_rows)
    print(f"WROTE {args.output}")
    for row in output_rows:
        print(f"{row['metric']}: delta={row['observed_delta']} CI=[{row['ci_low']},{row['ci_high']}]")


if __name__ == "__main__":
    main()
